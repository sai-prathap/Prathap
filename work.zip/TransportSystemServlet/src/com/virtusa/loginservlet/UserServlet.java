package com.virtusa.loginservlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.userbooking.model.UserBooking;
import com.virtusa.userbookingdao.UserBookingDaoImp;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String source = request.getParameter("source");
		String destination = request.getParameter("destination");
		String status = "pending";
		String cab_num = "0";
		String time = request.getParameter("user_time");
		String emp_id = request.getParameter("emp_id");
		int empid = Integer.valueOf(emp_id);
		UserBookingDaoImp aa = new UserBookingDaoImp();
		UserBooking user = new UserBooking(empid,source,destination,time,status,cab_num);
		aa.add(user);
		request.setAttribute("error", "Data added");
		request.getRequestDispatcher("user.jsp").forward(request, response);
		
	}

}
