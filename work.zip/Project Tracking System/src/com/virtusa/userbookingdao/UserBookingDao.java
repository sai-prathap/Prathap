package com.virtusa.userbookingdao;

import java.util.List;
import com.virtusa.userbooking.model.UserBooking;
public interface UserBookingDao {
	 UserBooking findById(String status);
	 List<UserBooking> findAll();
	 UserBooking update(UserBooking user);
	 UserBooking add(UserBooking data);
	 boolean delete(UserBooking user);
}
