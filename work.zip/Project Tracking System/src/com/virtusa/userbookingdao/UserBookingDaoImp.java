package com.virtusa.userbookingdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.virtusa.employee.dbCon.DBConnection;

import com.virtusa.userbooking.model.UserBooking;

public class UserBookingDaoImp implements UserBookingDao {
	private static final Logger log=Logger.getAnonymousLogger();
	private Connection connection=DBConnection.getConnection();
	private final String FINDEMP="select * from booking where staus=?";
	private final String ADDEMP="insert into Booking values(?,?,?,?,?,?)";
	private final String UPDATEEMP="update Booking set status=?,cabno=? where EmployeeID=?";
	private final String DELETEMP="delete from Booking where EmployeeID= ";
	private final String FINDALL="select * from booking where status='pending';";
	@Override
	public UserBooking findById(String status) {
		PreparedStatement ps=null;
		UserBooking user = null;
		try {
			ps=connection.prepareStatement(FINDEMP);
			ps.setString(1,status);
			ResultSet resultSet=ps.executeQuery();
			if(resultSet.next())
			{
				int id=resultSet.getInt("EmployeeID");
				String source=resultSet.getString("Source");
				String destination=resultSet.getString("Destination");
				String time=resultSet.getString("time");
				String cabno=resultSet.getString("cabno");
				user=new UserBooking(id,source,destination,time,status,cabno);
			}
		}catch(SQLException e) {
			e.printStackTrace();
			return null;
		}finally {
			if(ps!=null)
				try {
					ps.close();
				}catch(SQLException e) {
					e.printStackTrace();

				}

		}
		return user;
	}
	@Override
	public List<UserBooking> findAll() {
		PreparedStatement ps=null;
		List<UserBooking> userBook=new ArrayList<UserBooking>();
		try {
			ps=connection.prepareStatement(FINDALL);

			ResultSet resultSet=ps.executeQuery();


			while(resultSet.next())
			{int id=resultSet.getInt(1);
			String source=resultSet.getString(2);
			String destination=resultSet.getString(3);
			String time=resultSet.getString(4);
			String cabno=resultSet.getString(6);
			String status = resultSet.getString(5);
			UserBooking user=new UserBooking(id,source,destination,time,status,cabno);
			userBook.add(user);
			}


		}catch(SQLException e) {
			e.printStackTrace();

		}finally {
			if(ps!=null)
				try {
					ps.close();
				}catch(SQLException e) {
					e.printStackTrace();

				}
		}
		return userBook;
	}
	@Override
	public UserBooking update(UserBooking user) {
		PreparedStatement pst=null;
		try {
			pst=connection.prepareStatement(UPDATEEMP);
			pst.setString(1, user.getStatus());
			pst.setString(2, user.getCab_number());
			pst.setInt(3, user.getEmp_id());
			pst.executeUpdate();
			connection.commit();

			
		}catch(Exception e) {
			e.printStackTrace();

		}finally {
			if(pst!=null)
				try {
					pst.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
		}
		return user;
	}
	@Override
	public UserBooking add(UserBooking data) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement(ADDEMP);
			ps.setInt(1, data.getEmp_id());
			ps.setString(2, data.getSource());
			ps.setString(3, data.getDestination());
			ps.setString(4, data.getTime());
			ps.setString(5, data.getStatus());
			ps.setString(6, data.getCab_number());
			
			ps.executeUpdate();

			connection.commit();
		}catch(Exception e) {
			e.printStackTrace();

		}finally {
			if(ps!=null) {
				try {
					ps.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}}
		return data;
	}

	
	@Override
	public boolean delete(UserBooking user) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement(DELETEMP);
			ps.setLong(1, user.getEmp_id());
			int rows=ps.executeUpdate();
			connection.commit();
			if(rows!=1) return false;
			else return true;
		}catch(SQLException e) {
			e.printStackTrace();
			return false;
		}finally {
			if(ps!=null)
				try {
					ps.close();
				}catch(SQLException e) {
					e.printStackTrace();		
				}
		}

	}
	}

