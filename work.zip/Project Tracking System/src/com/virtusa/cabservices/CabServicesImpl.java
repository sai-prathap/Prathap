package com.virtusa.cabservices;

import java.util.List;

import com.virtusa.cabdao.CabDaoimpl;
import com.virtusa.cabmodel.Cab;

public class CabServicesImpl implements CabServices {
	CabDaoimpl cabser = new CabDaoimpl();
	@Override
	public Cab findById(int cabno) {
		// TODO Auto-generated method stub
		return cabser.findById(cabno);
	}

	@Override
	public List<Cab> findAll() {
		// TODO Auto-generated method stub
		return cabser.findAll();
	}

	@Override
	public Cab update(Cab cab) {
		// TODO Auto-generated method stub
		return cabser.update(cab);
	}

	@Override
	public Cab add(Cab cab) {
		// TODO Auto-generated method stub
		return cabser.add(cab);
	}

	@Override
	public boolean delete(Cab cab) {
		// TODO Auto-generated method stub
		return cabser.delete(cab);
	}

}
