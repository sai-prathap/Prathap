package com.virtusa.cabservices;

import java.util.List;

import com.virtusa.cabmodel.Cab;

public interface CabServices {
	 Cab findById(int cabno);
	 List<Cab> findAll();
	 Cab update(Cab cab);
	 Cab add(Cab cab);
	 boolean delete(Cab cab);
}
