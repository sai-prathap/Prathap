package com.virtusa.employeeservices;

import java.util.List;

import com.virtusa.employeedao.EmployeeImpl;
import com.virtusa.model.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	EmployeeImpl employeeservice = new EmployeeImpl();

	@Override
	public Employee findById(long empid) {
		// TODO Auto-generated method stub
		return employeeservice.findById(empid);
	}

	@Override
	public List<Employee> findAll() {
		// TODO Auto-generated method stub
		return employeeservice.findAll();
	}

	@Override
	public Employee update(Employee employee) {
		// TODO Auto-generated method stub
		return employeeservice.update(employee);
	}

	@Override
	public Employee add(Employee employee) {
		// TODO Auto-generated method stub
		return employeeservice.add(employee);
	}

	@Override
	public boolean delete(Employee employee) {
		// TODO Auto-generated method stub
		return delete(employee);
	}

}
