package com.virtusa.employeeservices;

import java.util.List;

import com.virtusa.model.Employee;

public interface EmployeeService {
	 Employee findById(long empid);
	 List<Employee> findAll();
	 Employee update(Employee employee);
	 Employee add(Employee employee);
	 boolean delete(Employee employee);

}
