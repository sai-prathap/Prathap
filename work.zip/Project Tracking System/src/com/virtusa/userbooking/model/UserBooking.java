package com.virtusa.userbooking.model;

public class UserBooking {
int emp_id; 
String source;
 String destination;
 String time;
 String status;
 String cab_number;
public UserBooking(int emp_id, String source, String destination, String time, String status, String cab_number) {
	super();
	this.emp_id = emp_id;
	this.source = source;
	this.destination = destination;
	this.time = time;
	this.status = status;
	this.cab_number = cab_number;
}
public int getEmp_id() {
	return emp_id;
}
public void setEmp_id(int emp_id) {
	this.emp_id = emp_id;
}
public String getSource() {
	return source;
}
public void setSource(String source) {
	this.source = source;
}
public String getDestination() {
	return destination;
}
public void setDestination(String destination) {
	this.destination = destination;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getCab_number() {
	return cab_number;
}
public void setCab_number(String cab_number) {
	this.cab_number = cab_number;
}

}
