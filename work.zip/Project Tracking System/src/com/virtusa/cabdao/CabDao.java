package com.virtusa.cabdao;

import java.util.List;

import com.virtusa.cabmodel.Cab;

public interface CabDao {
	 Cab findById(int cabno);
	 List<Cab> findAll();
	 Cab update(Cab cab);
	 Cab add(Cab cab);
	 boolean delete(Cab cab);
}
