package com.virtusa.cabdao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import java.util.logging.Logger;

import com.virtusa.cabmodel.Cab;
import com.virtusa.employee.dbCon.DBConnection;



public class CabDaoimpl implements CabDao {
	private static final Logger log=Logger.getAnonymousLogger();
	private Connection connection=DBConnection.getConnection();
	private final String FINDCAB="select * from Cab where cab_number=?";
	private final String ADDEMP="insert into Cab values(?,?,?)";
	private final String UPDATEEMP="update Cab set cab_driver_name=?,driver_phno=? where cab_number=?";
	private final String DELETEMP="delete from Cab where cab_number=/";
	private final String FINDALL="select * from Cab";
	@Override
	public Cab findById(int cabno) {
		PreparedStatement ps=null;
		Cab c = null;
		try {
			ps=connection.prepareStatement(FINDCAB);
			ps.setLong(1,cabno);
			ResultSet resultSet=ps.executeQuery();
			if(resultSet.next())
			{
				int num=resultSet.getInt("driver_phno");
				String name=resultSet.getString("cab_driver_name");
				String number=resultSet.getString("cab_number");
				c=new Cab(name,number,num);
			}
		}catch(SQLException e) {
			e.printStackTrace();
			return null;
		}finally {
			if(ps!=null)
				try {
					ps.close();
				}catch(SQLException e) {
					e.printStackTrace();

				}

		}
		return c;

	}

	@Override
	public List<Cab> findAll() {
		PreparedStatement ps=null;
		List<Cab> c=new ArrayList<Cab>();

		try {


			ps=connection.prepareStatement(FINDALL);

			ResultSet resultSet=ps.executeQuery();


			while(resultSet.next())
			{
				int num=resultSet.getInt("driver_phno");
				String number=resultSet.getString("cab_number");
				String name=resultSet.getString("cab_driver_name");
				Cab cab=new Cab(name,number,num);
				c.add(cab);
			}


		}catch(SQLException e) {
			e.printStackTrace();

		}finally {
			if(ps!=null)
				try {
					ps.close();
				}catch(SQLException e) {
					e.printStackTrace();

				}
		}
		return c;


	}

	@Override
	public Cab update(Cab c) {
		PreparedStatement pst=null;
		try {
			pst=connection.prepareStatement(UPDATEEMP);
			pst.setString(1, c.getCab_driver_name());
			pst.setInt(2, c.getDriver_phno());
			pst.setString(3, c.getCab_number());
			pst.executeUpdate();
			connection.commit();

			}catch(Exception e) {
			e.printStackTrace();

		}finally {
			if(pst!=null)
				try {
					pst.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
		}
		return c;
	}

	@Override
	public Cab add(Cab c) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement(ADDEMP);
			ps.setString(1, c.getCab_driver_name());
			ps.setInt(2, c.getDriver_phno());
			ps.setString(3, c.getCab_number());
			ps.executeUpdate();

			connection.commit();
		}catch(Exception e) {
			e.printStackTrace();

		}finally {
			if(ps!=null) {
				try {
					ps.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}}
		return c;
	}

	@Override
	public boolean delete(Cab cab) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement(DELETEMP);
			ps.setString(1, cab.getCab_number());
			int rows=ps.executeUpdate();
			connection.commit();
			if(rows!=1) return false;
			else return true;
		}catch(SQLException e) {
			e.printStackTrace();
			return false;
		}finally {
			if(ps!=null)
				try {
					ps.close();
				}catch(SQLException e) {
					e.printStackTrace();		
				}
		}

	}

}
