package com.virtusa.cabmodel;

public class Cab {
 String cab_driver_name;
 String cab_number;
 int driver_phno;
public Cab(String cab_driver_name, String cab_number, int driver_phno) {
	super();
	this.cab_driver_name = cab_driver_name;
	this.cab_number = cab_number;
	this.driver_phno = driver_phno;
}
public String getCab_driver_name() {
	return cab_driver_name;
}
public void setCab_driver_name(String cab_driver_name) {
	this.cab_driver_name = cab_driver_name;
}
public String getCab_number() {
	return cab_number;
}
public void setCab_number(String cab_number) {
	this.cab_number = cab_number;
}
public int getDriver_phno() {
	return driver_phno;
}
public void setDriver_phno(int driver_phno) {
	this.driver_phno = driver_phno;
}
 
}
