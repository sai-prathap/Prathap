package com.virtusa.employeedao;

import java.util.List;

import com.virtusa.model.Employee;
public interface EmployeeDao {
	 Employee findById(long empid);
	 List<Employee> findAll();
	 Employee update(Employee employee);
	 Employee add(Employee employee);
	 boolean delete(int id);
}

