package com.virtusa.employeedao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import java.util.logging.Logger;

import com.virtusa.employee.dbCon.DBConnection;
import com.virtusa.model.Employee;


public class EmployeeImpl implements EmployeeDao {
	private static final Logger log=Logger.getAnonymousLogger();
	private Connection connection=DBConnection.getConnection();
	private final String FINDEMP="select * from Employee where emp_id=?";
	private final String ADDEMP="insert into Employee values(?,?,?,?)";
	private final String UPDATEEMP="update Employee set emp_name=?,emp_password=?,emp_email =? where EmployeeID=?";
	private final String DELETEMP="delete from Employee where emp_id=?";
	private final String FINDALL="select * from Employee";
	@Override
	public Employee findById(long empid) {
		PreparedStatement ps=null;
		Employee employee = null;
		try {
			ps=connection.prepareStatement(FINDEMP);
			ps.setLong(1,empid);
			ResultSet resultSet=ps.executeQuery();
			if(resultSet.next())
			{
				long empid1=resultSet.getInt(1);
				String empname=resultSet.getString(2);
				String emppswrd=resultSet.getString(3);
				String empemail = resultSet.getString(4);
				employee=new Employee(empid1,empname,empemail,emppswrd);
			}
		}catch(SQLException e) {
			e.printStackTrace();
			return null;
		}finally {
			if(ps!=null)
				try {
					ps.close();
				}catch(SQLException e) {
					e.printStackTrace();

				}

		}
		return employee;

	}

	@Override
	public List<Employee> findAll() {
		PreparedStatement ps=null;
		List<Employee> listEmployee=new ArrayList<Employee>();

		try {


			ps=connection.prepareStatement(FINDALL);

			ResultSet resultSet=ps.executeQuery();


			while(resultSet.next())
			{
				long empid1=resultSet.getLong(1);
				String empname=resultSet.getString(2);
				String emppswrd=resultSet.getString(4);
				String empemail = resultSet.getString(3);
				Employee employee=new Employee(empid1,empname,empemail,emppswrd);			
				listEmployee.add(employee);
			}


		}catch(SQLException e) {
			e.printStackTrace();

		}finally {
			if(ps!=null)
				try {
					ps.close();
				}catch(SQLException e) {
					e.printStackTrace();

				}
		}
		return listEmployee;


	}

	@Override
	public Employee update(Employee employee) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement(UPDATEEMP);
			ps.setLong(1, employee.getEmpid());
			ps.setString(2, employee.getName());
			ps.setString(3, employee.getEmp_email());
			ps.setString(4, employee.getPassword());
			ps.executeUpdate();
			connection.commit();

			return employee;
		}catch(Exception e) {
			e.printStackTrace();

		}finally {
			if(ps!=null)
				try {
					ps.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
		}
		return employee;
	}

	@Override
	public Employee add(Employee employee) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement(ADDEMP);
			ps.setLong(1, employee.getEmpid());
			ps.setString(2, employee.getName());
			ps.setString(3, employee.getEmp_email());
			ps.setString(4, employee.getPassword());
			ps.executeUpdate();

			connection.commit();
			return employee;
		}catch(Exception e) {
			e.printStackTrace();

		}finally {
			if(ps!=null) {
				try {
					ps.close();
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}}
		return employee;
	}

	@Override
	public boolean delete(int id) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement(DELETEMP);
			ps.setLong(1, id);
			int rows=ps.executeUpdate();
			connection.commit();
			if(rows!=1) return false;
			else return true;
		}catch(SQLException e) {
			e.printStackTrace();
			return false;
		}finally {
			if(ps!=null)
				try {
					ps.close();
				}catch(SQLException e) {
					e.printStackTrace();		
				}
		}

	}
}