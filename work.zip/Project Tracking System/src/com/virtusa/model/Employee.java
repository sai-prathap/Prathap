package com.virtusa.model;

public class Employee {
	    String name;
	     long empid;
	   String emp_email;
	 String password;

	  public Employee(long empid1, String empname,String email, String password){
	      this.empid = empid1;
	      this.name= empname;
	      this.emp_email = email;
	      this.password=password;
	   }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getEmpid() {
		return empid;
	}

	public void setEmpid(long empid) {
		this.empid = empid;
	}

	public String getEmp_email() {
		return emp_email;
	}

	public void setEmp_email(String emp_email) {
		this.emp_email = emp_email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


}
