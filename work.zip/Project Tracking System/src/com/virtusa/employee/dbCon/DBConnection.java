package com.virtusa.employee.dbCon;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Logger;

public class DBConnection {
private static Connection connection=null;
private static final Logger log=Logger.getAnonymousLogger();
public DBConnection() {
	try
	{
		Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/TrackingSystem","root","1");
		log.info("connection to database was established" + connection);
	}catch(ClassNotFoundException e) {
		//log.error(e);
		e.printStackTrace();
	}catch(Exception e) {
		//log.error(e);
		e.printStackTrace();
	}
}public static Connection getConnection(){
	try {
		if(connection==null||connection.isClosed())
		{
			new DBConnection();
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}return connection;
}
}
