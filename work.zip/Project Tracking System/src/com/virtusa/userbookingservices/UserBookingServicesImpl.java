package com.virtusa.userbookingservices;

import java.util.List;

import com.virtusa.userbooking.model.UserBooking;
import com.virtusa.userbookingdao.UserBookingDaoImp;

public class UserBookingServicesImpl implements UserBookingServices{
	UserBookingDaoImp userser = new UserBookingDaoImp();
	@Override
	public UserBooking findById(String status) {
		// TODO Auto-generated method stub
		return userser.findById(status);
	}

	@Override
	public List<UserBooking> findAll() {
		// TODO Auto-generated method stub
		return userser.findAll();
	}

	@Override
	public UserBooking update(UserBooking user) {
		// TODO Auto-generated method stub
		return userser.update(user);
	}

	@Override
	public UserBooking add(UserBooking data) {
		// TODO Auto-generated method stub
		return userser.add(data);
	}

	@Override
	public boolean delete(UserBooking user) {
		// TODO Auto-generated method stub
		return userser.delete(user);
	}

}
