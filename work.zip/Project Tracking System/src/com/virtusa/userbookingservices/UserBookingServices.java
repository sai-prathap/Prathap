package com.virtusa.userbookingservices;

import java.util.List;

import com.virtusa.userbooking.model.UserBooking;

public interface UserBookingServices {
	 UserBooking findById(String status);
	 List<UserBooking> findAll();
	 UserBooking update(UserBooking user);
	 UserBooking add(UserBooking data);
	 boolean delete(UserBooking user);
}
